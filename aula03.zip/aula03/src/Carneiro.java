public class Carneiro extends Animal{
    public Carneiro(){
        this.nome = "Xaucarnero";
        this.numeroPatas = 4;
    }
    @Override
    public void som() {
        System.out.println("MÉÉÉÉÉ");
    }
}
