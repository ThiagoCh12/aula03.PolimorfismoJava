public class Zoo {
    public static void main(String[]args){
        Vaca Mimosa = new Vaca();
        Gato Gorducho = new Gato();
        Carneiro Xaucarnero = new Carneiro();

        Animal bichos [] = {Mimosa, Gorducho, Xaucarnero };

        for(Animal animal : bichos){
                System.out.println(animal.nome + " é de classe " + animal.getClass().getName() +
                        " tem " + animal.numeroPatas + " patas e faz ");
                animal.som();
                System.out.println();
        }
    }
}
