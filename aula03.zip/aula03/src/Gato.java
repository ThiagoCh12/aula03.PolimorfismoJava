public class Gato extends Animal{
    public Gato(){
        this.nome = "Gorducho";
        this.numeroPatas = 4;
    }

    @Override
    public void som() {
        System.out.println("MIAUUUUU");
    }
}
